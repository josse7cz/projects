package rasterization;

/**
 * prubezna uloha cislo 1
 * 
 * @author Josef Janda
 * @version 9.4.2017
 */
public interface LineRasterizer {
	LineRasterizer drawLine(int x1, int y1, int x2, int y2, int color);

}
