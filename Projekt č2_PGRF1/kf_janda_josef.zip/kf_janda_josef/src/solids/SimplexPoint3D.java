package solids;

import transforms.Point3D;

public class SimplexPoint3D extends SolidPoint3D {
	public SimplexPoint3D() {
		vertices.add(new Point3D(0,0,0));//vrcholy
		vertices.add(new Point3D(1,0,0));
		vertices.add(new Point3D(0,1,0));
		vertices.add(new Point3D(0,0,1));
		indices.add(0);//hrany
		indices.add(1);
		indices.add(1);
		indices.add(2);
		indices.add(2);
		indices.add(0);
		indices.add(0);
		indices.add(3);
		indices.add(1);
		indices.add(3);
		indices.add(2);
		indices.add(3);
	}
}
