package rendering;

import java.util.List;
import java.util.Optional;
import rasterization.LineRasterizer;
import transforms.Mat4;
import transforms.Point3D;
import transforms.Vec3D;

public class RendererPoint3D implements Renderer<Point3D> {

	LineRasterizer liner;

	public RendererPoint3D(LineRasterizer liner) {

		this.liner = liner;
	}

	@Override
	public void render(final List<Point3D> vertices, final List<Integer> indices, final int startIndex,
			final int indexCount, final rendering.Renderer.PrimitiveType type, final Mat4 mat) {

		class Impl {
			void renderLineList() {
				if (startIndex < 0 || startIndex + indexCount > indices.size() || indexCount % 2 != 0) {
					System.err.println("Illegal argument");
					return;
				}
				for (int i = startIndex; i < startIndex + indexCount; i += 2) {
					final Point3D p1 = vertices.get(indices.get(i));
					final Point3D p2 = vertices.get(indices.get(i + 1));
					transformLine(p1, p2);
				}
			}

			void renderTriangleList() {
				// 3x transformLine?
				for (int i = startIndex; i < startIndex + indexCount; i += 2) {
					final Point3D p1 = vertices.get(indices.get(i));
					final Point3D p2 = vertices.get(indices.get(i + 2));
					final Point3D p3 = vertices.get(indices.get(i + 3));
					transformLine(p1, p2);
					transformLine(p2, p3);//
					transformLine(p3, p1);
				}
			}

			private void transformLine(final Point3D p1, final Point3D p2) {
				final Point3D tp1 = p1.mul(mat);
				final Point3D tp2 = p2.mul(mat);
				if (tp1.getW() <= 0 || tp2.getW() <= 0)
					return;
				final Optional<Vec3D> dp1 = tp1.dehomog();
				final Optional<Vec3D> dp2 = tp2.dehomog();
				dp1.ifPresent((final Vec3D v1) -> {
					dp2.ifPresent(v2 -> {
						drawLine(v1, v2);
					});
				});
			}

			private void drawLine(final Vec3D p1, final Vec3D p2) {// viewportova
																	// transformace
																	// (z NDC do
																	// okna):
				final double x1 = (p1.getX() + 1) * 0.5 * (800 - 1);
				final double y1 = (-p1.getY() + 1) * 0.5 * (600 - 1);
				final double x2 = (p2.getX() + 1) * 0.5 * (800 - 1);
				final double y2 = (-p2.getY() + 1) * 0.5 * (600 - 1);
				// TODO zrusit BufferedImage, predelat na LineRasterizer
				// TODO liner.drawLine(x1, y1, x2, y2)

				liner.drawLine((int) x1, (int) y1, (int) x2, (int) y2, 0xFFFFFF);
			}
		}

		switch (type) {
		case LINE_LIST:
			new Impl().renderLineList();
			break;
		case TRIANGLE_LIST:
			new Impl().renderTriangleList();
			break;
		}
	}

}
